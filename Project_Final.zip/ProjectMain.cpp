#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <assert.h>
#include <string.h>
#include <windows.h>
#include <conio.h>
#include "MainFunc.h"
#include "StructFunc.h"
#include "MainFunc.h"

int main()
{
	mainMenu();
	return 0;
}


