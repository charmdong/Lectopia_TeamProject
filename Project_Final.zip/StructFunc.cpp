#include <stdio.h>
#include <string.h>
#include <time.h>
#include <stdlib.h>
#include <assert.h>
#include "Structure.h"
#include "StructFunc.h"
//#include "MainFunc.h"

void deviceMemcpy(void *p1, void *p2)
{
	Device *val1 = (Device *)p1, *val2 = (Device *)p2;

	strcpy(val1->deviceName, val2->deviceName);
	strcpy(val1->company, val2->company);
	strcpy(val1->indate, val2->indate);
	val1->reserCnt = val2->reserCnt;
}

void devicePrint(void *p)
{
	Device *val = (Device *)p;
	printf("��ġ�� : %s\n", val->deviceName);
	printf("���� ���� : %s\n", val->company);
	printf("��� ���� : %s\n", val->indate);
}

int deviceNameCmp(void *p1, void *p2)
{
	Device *val1 = (Device *)p1, *val2 = (Device *)p2;
	if (!strcmp(val1->deviceName, val2->deviceName))
		return 1;
	return 0;
}

void deviceInit(void *p)
{
	Device *val = (Device *)p;
	strcpy(val->deviceName, "");
	strcpy(val->company, "");
	strcpy(val->indate, "");
	val->reserCnt = 0;
}

//==============================================//
void reserveMemcpy(void *p1, void *p2)
{
	Reserve *val1 = (Reserve *)p1, *val2 = (Reserve *)p2;

	strcpy(val1->deviceName, val2->deviceName);
	val1->hour = val2->hour;
	val1->min = val2->min;
	val1->reStatus = val2->reStatus;
	val1->mode = val2->mode;
}
void reservePrint(void *p)
{
	Reserve * val = (Reserve *)p;

	printf("[%s]>>>>\n", val->deviceName);
	printf("         %d : ", val->hour);
	printf("%d\n", val->min);
	if (val->reStatus == 1)
		printf("         ON ����\n");
	else
		printf("         OFF ����\n");
	if (!strcmp(val->deviceName, "AIRCOND")) {      //   ������
		if (val->mode == 1)
			printf("       ��� : ��ǳ\n");
		else if (val->mode == 2)
			printf("       ��� : ��ǳ\n");
		else if (val->mode == 3)
			printf("       ��� : ��ǳ\n");
		else if (val->mode == 4)
			printf("       ��� : �ڿ�ǳ\n");
		else
			;
	}
	else if (!strcmp(val->deviceName, "LAUNDRY")) {  //   ��Ź��
		if (val->mode == 1)
			printf("       ��� : �⺻\n");
		else if (val->mode == 2)
			printf("       ��� : ���\n");
		else
			printf("       ��� : ���Ż��\n");
	}
	else {                                 //   ����û����
		if (val->mode == 1)
			printf("       ��� : ����\n");
		else
			printf("       ��� : ����\n");
	}
	printf("+-----------------------------+\n");
}

int reserveCmp(void *p1, void *p2)
{
	Reserve *val1 = (Reserve *)p1, *val2 = (Reserve *)p2;
	if (val1->deviceName == val2->deviceName)
	{
		if (val1->hour == val2->hour && val1->min == val2->min)
			return 1;
		else
			return 0;
	}
	else
		return 0;
}

int reserveNameCmp(void *p1, void *p2) //������ 1
{
	Reserve *val1 = (Reserve *)p1, *val2 = (Reserve *)p2;

	if (!strcmp(val1->deviceName, val2->deviceName))
		return 1;
	else
		return 0;
}

int reserveTimeCmp(void *p1, void *p2)
{

	Reserve *val = (Reserve *)p1;
	tm *cur = (tm *)p2;
	if (val->hour > cur->tm_hour)
		return 1; // ���� �ð����� ���� �� ���.
	else if (val->hour == cur->tm_hour) { // ���� �ð���
		if (val->min  > cur->tm_min) // ������ ���.
			return 1;
		else if (val->min == cur->tm_min) // ���� ���.
			return 0;
		return -1; // ���� �ð��� ������ ���.
	}
	return -1;// ���� �ð����� ������ ���.
}

void reserveInit(void *p)
{
	Reserve *val = (Reserve *)p;
	strcpy(val->deviceName, "");
	val->hour = val->min = val->reStatus = -1;
	val->mode = 0;
}

//==============================================//
void statusMemcpy(void *p1, void *p2)
{
	Status *val1 = (Status *)p1, *val2 = (Status *)p2;
	strcpy(val1->deviceName, val2->deviceName);
	val1->status = val2->status;
	val1->mode = val2->mode;
	val1->temper = val2->temper;
}

int statusNameCmp(void *p1, void *p2)
{
	Status *val1 = (Status *)p1;
	char *device = (char*)p2;
//	printf("<%s>\n", device);
	if (!strcmp(val1->deviceName, device))
		return 1;
	return 0;
}



void statusInit(void *p)
{
	Status *val = (Status *)p;
	strcpy(val->deviceName, "");
	val->status = -1;
	val->mode = 0;
	val->temper = 23;
}
//===============================================//
void environMemcpy(void *p1, void *p2)
{
	Environ *val1 = (Environ *)p1, *val2 = (Environ *)p2;

	val1->nowTemper = val2->nowTemper;
	val1->clean = val2->clean;
}

void environInit(void *p)
{
	((Environ *)p)->nowTemper = ((Environ *)p)->clean = 0;
}

void environPrint(void *p)
{
	if (((Environ *)p)->nowTemper >= 25)
		printf("������ �ڵ����� �����µ� : %d��\n", ((Environ *)p)->nowTemper);
	else
		printf("������ �ڵ���� �������� �ʾҽ��ϴ�.\n");
	if (((Environ*)p)->clean >= 10)
		printf("����û���Ⱑ %d��/���϶� �ڵ����� �۵��˴ϴ�.\n", ((Environ*)p)->clean);
	else
		printf("����û���� �ڵ���� �������� �ʾҽ��ϴ�.\n");
}

int environCmp(void *p1, void *p2) //������ 1
{
	Environ *val1 = (Environ *)p1, *val2 = (Environ *)p2;

	if ((val1->nowTemper==val2->nowTemper) && (val1->clean==val2->clean) )
		return 1;
	else
		return 0;
}
//===============================================//
int createList(List *lp)
{
	if (lp == NULL)
		return 0;
	lp->head = (Node*)malloc(sizeof(Node));
	if (lp->head == NULL)
		return 0;

	lp->tail = (Node*)malloc(sizeof(Node));
	if (lp->tail == NULL)
		return 0;

	lp->head->next = lp->tail;
	lp->tail->prev = lp->head;
	lp->head->prev = lp->head;
	lp->tail->next = lp->tail;
	return 1;
}

void destroyList(List *lp)
{
	Node *cur, *nextp;
	cur = lp->head->next;

	if (lp == NULL)
		return;

	while (cur != lp->tail) {
		nextp = cur->next;
		free(cur);
		cur = nextp;
	}

	free(lp->head);
	free(lp->tail);
	lp->head = lp->tail = NULL;
}

int addLast(List *lp, void *data, size_t size, void(*memcpy)(void *, void*))
{
	Node *np;

	if (lp == NULL) return 0;

	np = (Node*)malloc(sizeof(Node) + size);
	if (np == NULL) return 0;

	memcpy(np + 1, data);
	np->next = lp->tail;
	lp->tail->prev->next = np;
	np->prev = lp->tail->prev;
	lp->tail->prev = np;

	return 1;
}

void displayList(List *lp, void(*dataPrint)(void *))
{
	Node *cur;

	if (lp == NULL) return;

	cur = lp->head->next;

	while (cur != lp->tail) {
		dataPrint(cur + 1);
		cur = cur->next;
	}
	//printf("\n");
}

Node *searchNode(List *lp, void *data, int(*dataCompare)(void *, void*))
{
	Node *cur;

	if (lp == NULL) return NULL;

	cur = lp->head->next;

	while (cur != lp->tail) {
		if (dataCompare(cur + 1, data))
			return cur;
		cur = cur->next;
	}
	return NULL;
}

int removeNode(List *lp, void *data, int(*dataCompare)(void *, void*))
{
	Node *delp;

	if (lp == NULL) return 0;

	delp = searchNode(lp, data, dataCompare);
	if (delp == NULL) return 0;

	delp->prev->next = delp->next;
	delp->next->prev = delp->prev;
	free(delp);
	return 1;
}

//=============================================//